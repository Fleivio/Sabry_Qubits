module Main(main) where

import Quantum.Basis

main :: IO ()
main = f
